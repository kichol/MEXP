﻿using MediatR;

namespace MediaExpert.Application.Features.Products.Queries.GetProductsList
{
    public class GetProductListQuery : IRequest<List<ProductListVm>>
    {

    }
}
    