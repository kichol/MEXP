export interface Product {
        productId: string,
        code: string
        name: string
        price: number
}
